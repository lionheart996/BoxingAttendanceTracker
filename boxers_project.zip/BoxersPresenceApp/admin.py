from django.contrib import admin
from .models import Boxer, Attendance

admin.site.register(Boxer)
admin.site.register(Attendance)